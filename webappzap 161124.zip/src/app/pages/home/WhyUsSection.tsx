import React from 'react';
import Image from 'next/image';
import professionals from '@/assets/img/professionals.svg';
import expertteam from '@/assets/img/expert-team.svg';
import totalexperience from '@/assets/img/total-experience.svg';
import servicequality from '@/assets/img/service-quality.svg';

const WhyUsSection = () => {
  return (
    <section className=" relative py-12 bg-[#00001d]">
      <div className="container mx-auto text-center mb-5  lg:mb-12">
        <div className="lg:px-20 px-5 text-white font-normal   mt-2">
          <h1 data-aos="fade-up" data-aos-duration="1000" className='italic mb-5 lg:mb-10 text-xl lg:text-2xl'>
            <span className='border-b-2 border-red-500 pb-2'>  Why</span> People Choose Us
          </h1>
          <h2 data-aos="fade-up" data-aos-duration="1000" className="text-white font-extrabold text-2xl lg:text-5xl mb-5 lg:mb-10 italic">
            Because We Give Our Best
          </h2>

          <div className="container mx-auto grid lg:grid-cols-4 sm:grid-cols-1 md:grid-cols-2 gap-6 my-5">
            {[
              { src: professionals, alt: "Professional Work", title: "Professional Work" },
              { src: expertteam, alt: "Expert Team", title: "Expert Team" },
              { src: totalexperience, alt: "16+ Years Experience", title: "16+ Years Experience" },
              { src: servicequality, alt: "Best Service Quality 24*7", title: "Best Service Quality 24*7" },
            ].map((item, index) => (
              <div
                key={index}
                data-aos="zoom-in"
                data-aos-duration={`${1000 + index * 200}`}
                className=" bg-darkBlue/15 border border-dashed border-purple rounded-sm backdrop-blur-md px-8 py-14  transition-transform duration-300 hover:-translate-y-2"
              >
                <div className=" flex flex-col justify-center items-center text-center z-10">
                  <div className="  w-24 h-24 mb-6">
                    <Image src={item.src} alt={item.alt} width={75} height={75} className='object-contain text-center' />
                  </div>
                  <div className="content">
                    <h3 className="text-sm font-semibold italic text-white mb-2">{item.title}</h3>
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>
      </div>
    </section>
  );
};

export default WhyUsSection;
