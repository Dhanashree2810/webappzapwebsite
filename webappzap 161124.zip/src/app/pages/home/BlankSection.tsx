import React from 'react'

export default function BlankSection() {
    return (
        <div className='relative bg-[#00001d]'>
            <div className='container py-20 px-8'>
                <div className="py-10 px-20">
                </div>
            </div>
        </div>
    )
}
