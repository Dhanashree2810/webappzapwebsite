import React from 'react'
import ContactUs from '../pages/contactus/ContactUs'

export default function page() {
  return (
    <div>
      <ContactUs/>
    </div>
  )
}
