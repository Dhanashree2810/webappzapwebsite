import React from 'react'
import AboutUs from '../pages/aboutus/AboutUs'

export default function page() {
  return (
    <div>
      <AboutUs/>
    </div>
  )
}
