'use client'
import { ServicesSection } from '../pages/home/ServiceSection'
import { usePathname } from 'next/navigation';

export default function page() {
  const pathname = usePathname();

  return (
    <div>
      <ServicesSection pathname={pathname}/>
    </div>
  )
}
